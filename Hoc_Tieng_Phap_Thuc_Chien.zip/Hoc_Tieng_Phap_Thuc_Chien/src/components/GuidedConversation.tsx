import { useState } from 'react'
import { Mic, RotateCcw, Square } from 'lucide-react'
import type { Lesson } from '../data'
import { useRecognition } from '../speech'
import { AudioButton, Bar } from './common'

export function GuidedConversation({ lesson }: { lesson: Lesson }) {
  const [turn, setTurn] = useState(0)
  const [draft, setDraft] = useState('')
  const [compared, setCompared] = useState(false)
  const [readCue, setReadCue] = useState(false)
  const microphone = useRecognition()
  const turns = lesson.dialogue.flatMap((line, index) => {
    if (line[0] !== 'Linh') return []
    const previous = lesson.dialogue[index - 1]
    const partner = previous?.[0] !== 'Linh' ? previous : undefined
    return [{ partner, line }]
  })
  const current = turns[turn]

  function reset(next = 0) {
    setTurn(next)
    setDraft('')
    setCompared(false)
    setReadCue(false)
  }

  if (!current) return <section className="empty-state"><h2>Bạn đã nói qua {turns.length} lượt</h2><p>Thử lượt nữa với thông tin của bạn, như tên, giờ hoặc địa điểm khác.</p><button className="button secondary" onClick={() => reset()}><RotateCcw size={17} /> Luyện lại</button></section>
  const { partner, line } = current
  return <div className="guided-conversation">
    <div className="lesson-progress"><Bar value={turn / turns.length * 100} label="Tiến độ hội thoại mẫu" /><p>Lượt {turn + 1}/{turns.length} · Bạn đóng vai Linh</p></div>
    {partner && <article className="guided-partner"><div><strong>{partner[0]}</strong><p lang="fr">{partner[1]}</p>{readCue && <p className="muted">{partner[2]}</p>}</div><AudioButton text={partner[1]} rate={0.8} compact /></article>}
    <div className="guided-prompt"><h3>Đến lượt bạn</h3><p>Diễn đạt ý sau bằng tiếng Pháp: {line[2]}</p></div>
    <textarea className="input" rows={3} maxLength={1500} value={draft} onChange={event => { setDraft(event.target.value); setCompared(false) }} lang="fr" aria-label="Câu đáp của bạn" placeholder="Gõ hoặc nói câu trả lời của bạn" />
    <div className="token-row">
      {microphone.supported && <button className="button secondary" onClick={() => microphone.listen(value => { setDraft(value); setCompared(false) })}>{microphone.recording ? <Square size={17} /> : <Mic size={17} />}{microphone.recording ? 'Dừng' : 'Nói câu trả lời'}</button>}
      {partner && <button className="text-button" aria-expanded={readCue} onClick={() => setReadCue(!readCue)}>{readCue ? 'Ẩn bản dịch câu hỏi' : 'Xem nghĩa câu hỏi'}</button>}
      <button className="button primary" disabled={!draft.trim()} onClick={() => setCompared(true)}>Đối chiếu câu đáp</button>
    </div>
    {microphone.error && <p className="notice" role="status">{microphone.error}</p>}
    {compared && <>
      <div className="mission-compare"><div><h3>Một cách nói</h3><p lang="fr">{line[1]}</p><AudioButton text={line[1]} rate={0.8} compact /></div></div>
      <button className="button primary" onClick={() => reset(turn + 1)}>{turn + 1 < turns.length ? 'Lượt tiếp theo' : 'Kết thúc hội thoại'}</button>
    </>}
  </div>
}
